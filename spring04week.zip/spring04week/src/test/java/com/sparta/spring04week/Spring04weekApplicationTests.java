package com.sparta.spring04week;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring04weekApplicationTests {

    @Test
    void contextLoads() {
    }

}
