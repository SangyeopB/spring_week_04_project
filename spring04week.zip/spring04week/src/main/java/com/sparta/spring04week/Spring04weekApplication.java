package com.sparta.spring04week;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Spring04weekApplication {

    public static void main(String[] args) {
        SpringApplication.run(Spring04weekApplication.class, args);
    }

}
